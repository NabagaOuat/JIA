<?php
header('Content-Type: application/json');

// Incluez votre fichier de configuration de base de données ici
require_once 'C:/xampp/htdocs/TheEvent/db.php';

$username = $_POST['username'];
$password = $_POST['password'];

$query = "SELECT * FROM administrateurs WHERE nom_utilisateur = :username AND mot_de_passe = :password";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':username', $username);
$stmt->bindParam(':password', $password);
$stmt->execute();

$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if ($admin) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Nom d\'utilisateur ou mot de passe incorrect.']);
}
