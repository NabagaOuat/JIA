<?php
// Incluez la bibliothèque PHPExcel
require_once 'C:/xampp/htdocs/TheEvent/api/Classes/PHPExcel.php';

// Incluez votre fichier de configuration de base de données ici
require_once 'C:/xampp/htdocs/TheEvent/db.php';

// Créez un nouvel objet PHPExcel
$objPHPExcel = new PHPExcel();

// Définissez les propriétés du document
$objPHPExcel->getProperties()->setCreator("Votre nom")
                             ->setLastModifiedBy("Votre nom")
                             ->setTitle("Liste des utilisateurs")
                             ->setSubject("Liste des utilisateurs")
                             ->setDescription("Liste des utilisateurs dans la base de données.")
                             ->setKeywords("utilisateurs liste excel")
                             ->setCategory("Liste des utilisateurs");

// Ajoutez des en-têtes
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'Nom')
            ->setCellValue('B1', 'Contact')
            ->setCellValue('C1', 'Courriel')
            ->setCellValue('D1', 'Poste')
            ->setCellValue('E1', 'Société')
            ->setCellValue('F1', 'Thème')
            ->setCellValue('G1', 'Date d\'inscription');

// Récupérez les données des utilisateurs
$query = "SELECT nom, contact, courriel, poste, societe, theme, date_inscription FROM utilisateurs";
$stmt = $pdo->query($query);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Ajoutez les données des utilisateurs
$rowIndex = 2;
foreach ($users as $user) {
    $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A' . $rowIndex, $user['nom'])
                ->setCellValue('B' . $rowIndex, $user['contact'])
                ->setCellValue('C' . $rowIndex, $user['courriel'])
                ->setCellValue('D' . $rowIndex, $user['poste'])
                ->setCellValue('E' . $rowIndex, $user['societe'])
                ->setCellValue('F' . $rowIndex, $user['theme'])
                ->setCellValue('G' . $rowIndex, $user['date_inscription']);
    $rowIndex++;
}

// Définissez la feuille active
$objPHPExcel->setActiveSheetIndex(0);

// Définissez le nom de la feuille
$objPHPExcel->getActiveSheet()->setTitle('Utilisateurs');

// Créez le fichier Excel
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="liste_utilisateurs.xlsx"');
header('Cache-Control: max-age=0');

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
